var express = require('express')
//var query = require('../BO/query');
//var con = require('../DAO/database');
//var valid = require('../BO/Validation')
//var router = express.Router();
var app = express();
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())
app.post('/shopping', function (req, res) {

    console.log("INSERTED SUCESSFULLY");
  var response = { username: req.body.username, password: req.body.password };
  
  if(req.body.usernamne != "" || req.body.password != ""){
   // valid.insertvalidation(response);

    res.send("INSERTED SUCESSFULLY")
  }
  else{

  res.send("Field Cannot Empty") 
  }
});
app.listen(3000);
console.log("listening........");


// app.post('/getpsw',function (req, res){
// var id = req.body.id;
// var data = query.fetch(id);
// console.log(data);
// res.send(data);
// });

//module.exports.app = app;
//module.exports.router = router;cd 