import React, { Component } from "react";

const Footer = props => {
  return (
    <footer>
      <p className="footer-links">
        <a
          href="https://www.facebook.com/"
          target="_blank"
        >
          Facebook
        </a>
        <span> / </span>
        <a href="mailto:arunkumar.ravindran@bpmlinks.com" target="_blank">
          Need any help?
        </a>
        <span> / </span>
        <a href="https://www.instagram.com/accounts/login/" target="_blank">
          Instagram
        </a>
      </p>
      <p>
        &copy; 2019 <strong>Shoppy</strong> - Online Shopping Cart
      </p>
    </footer>
  );
};

export default Footer;
