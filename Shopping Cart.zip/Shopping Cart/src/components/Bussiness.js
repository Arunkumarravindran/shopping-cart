
var request = require('request');


exports.checkOut = (data, callback) => {
    console.log(data);
    request.post(
        {
            url: 'http://localhost:3000/shopping',
            body: data,
            json: true
        },
        function (error, httpResponse, body) {
            console.log('error', error);
            console.log('statusCode', httpResponse && httpResponse.statusCode);
            console.log('body', body);

        //         if (httpResponse && httpResponse.statusCode == 200) {


        //             var bodyJSONObj = JSON.parse(body);
        //             var status = bodyJSONObj.status;
        //             var userRole = bodyJSONObj.userRole;
        //            console.log(status);
        //             console.log(userRole);
        //             if (status === 'SUCCESS') {
        //                 callback(null, body);
        //             } else if (status === 'FAILED') {
        //                 callback(new Error(bodyJSONObj.errorMsg), null);
        //             } else {
        //                 callback(new Error('System is not available right now, please try again later.'), null);
        //             }
        //         } else {
        //             callback(new Error('System is not available right now, please try again later.'), null);
        //         }

         });
}
